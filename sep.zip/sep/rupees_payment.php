<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rupees Payment</title>
    <link rel="stylesheet" href="./css/rupeesPayment.css">
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f2f2f2;
}

.container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
}

.card {
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    margin: 10px;
    padding: 20px;
}

h2 {
    color: #333;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

th, td {
    border: 1px solid #ddd;
    padding: 8px;
}

th {
    background-color: #f2f2f2;
}

button {
    padding: 10px 20px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 3px;
    cursor: pointer;
}

button:hover {
    background-color: #45a049;
}

.receipt {
    margin-top: 20px;
}

.receipt h1 {
    color: #333;
}

.receipt p {
    margin-bottom: 10px;
}

.receipt table {
    width: 100%;
    border-collapse: collapse;
}

.receipt th, .receipt td {
    border: 1px solid #ddd;
    padding: 8px;
}

.receipt th {
    background-color: #f2f2f2;
}

#printButton {
    display: none;
}

    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <?php
            session_start();if (isset($_GET['registration_number'])) {
                $registrationNumber = $_GET['registration_number'];

                // Database connection
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "students";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch student details from database
                $sql = "SELECT Registration_Number, Name, branch, course FROM students WHERE Registration_Number = '$registrationNumber'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Output student details
                    while ($row = $result->fetch_assoc()) {
                        // Store student details in variables
                        $registrationNumber = $row['Registration_Number'];
                        $name = $row['Name'];
                        $branch = $row['branch'];
                        $course = $row['course'];

                        // Output student details
                        echo "<h2>Student Details</h2>";
                        echo "<p>Registration Number: " . $registrationNumber . "</p>";
                        echo "<p>Name: " . $name . "</p>";
                        echo "<p>Branch: " . $branch . "</p>";
                        echo "<p>Course: " . $course . "</p>";
                    }
                } else {
                    echo "<p>No student details found.</p>";
                }

                $conn->close();
            } else {
                echo "<p>No registration number provided.</p>";
            }
            ?>
        </div>
        <div class="card">
            <h2>Selected Subjects</h2>
            <table>
                <thead>
                    <tr>
                        <th>Index</th>
                        <th>Subject Name</th>
                        <th>Subject Code</th>
                        <th>Rupees</th>
                    </tr>
                </thead>
                <tbody id="selectedRowsBody"></tbody>
            </table>
        </div>
    </div>
    <div class="card">
        <h2>Pay with Rupees</h2>
        <div class="rupeesPaymentContent">
            <h1>Complete Payment via Razorpay</h1>
            <div id="amount"></div>
            <button id="payButton">Pay Now</button>
        </div>
    </div>
    <div id="transactionDetailsDiv" class="receipt" style="display: none;">
        <h1>Receipt</h1>
        <?php
        if (isset($registrationNumber) && isset($name) && isset($branch) && isset($course)) {
            echo "<p><strong>Registration Number:</strong> $registrationNumber</p>";
            echo "<p><strong>Name:</strong> $name</p>";
            echo "<p><strong>Branch:</strong> $branch</p>";
            echo "<p><strong>Course:</strong> $course</p>";
        }
        ?>
        <p><strong>Payment Type:</strong> Rupees</p>
        <p><strong>Amount:</strong> <span id="paymentAmount"></span> INR</p>
        <p><strong>Transaction ID:</strong> <span id="transactionId"></span></p>
        <h2>Selected Subjects</h2>
        <table>
            <thead>
                <tr>
                    <th>Index</th>
                    <th>Subject Name</th>
                    <th>Subject Code</th>
                    <th>Rupees</th>
                </tr>
            </thead>
            <tbody id="additionalTableBody"></tbody>
        </table>
        <button id="printButton">Print Receipt</button>
    </div>

    <script>
        document.getElementById("amount").innerText = sessionStorage.getItem('rupeesSum');
        var selectedRows = JSON.parse(sessionStorage.getItem("selectedRows"));

        var selectedRowsBody = document.getElementById("selectedRowsBody");
        var index = 1;
        if (selectedRows) {
            selectedRows.forEach(function (row) {
                var newRow = document.createElement("tr");
                newRow.innerHTML = `
                <td>${index}</td>
                <td>${row.Subject_Name}</td>
                <td>${row.Subject_Code}</td>
                <td>${row.Rupees}</td>
            `;
                selectedRowsBody.appendChild(newRow);
                index++;
            });
        }

        var additionalTableBody = document.getElementById("additionalTableBody");
        if (selectedRows) {
            selectedRows.forEach(function (row, index) {
                var newRow = document.createElement("tr");
                newRow.innerHTML = `
                <td>${index + 1}</td>
                <td>${row.Subject_Name}</td>
                <td>${row.Subject_Code}</td>
                <td>${row.Rupees}</td>
            `;
                additionalTableBody.appendChild(newRow);
            });
        }

        const payButton = document.getElementById("payButton");

        payButton.addEventListener("click", function () {
            const registrationNumber = "<?php echo isset($registrationNumber) ? $registrationNumber : 'null'; ?>";
            const rupeesSum = sessionStorage.getItem("rupeesSum");
            const selectedRows = JSON.parse(sessionStorage.getItem("selectedRows"));

            var options = {
                "key": "rzp_test_byPLZtNtsJuOI3",
                "amount": rupeesSum * 100, // Amount is in currency subunits. Default currency is INR.
                "currency": "INR",
                "name": "Your Company Name",
                "description": "Test Transaction",
                "handler": function (response) {
                    sessionStorage.setItem("transactionId", response.razorpay_payment_id);
                    document.getElementById("printButton").style.display = "block";
                    displayReceipt();

                    fetch('update_database.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            transactionId: sessionStorage.getItem("transactionId"),
                            registrationNumber: registrationNumber,
                            rupeesSum: rupeesSum,
                            selectedRows: selectedRows
                        })
                    }).then(response => response.json()).then(data => {
                        if (data.success) {
                            alert("Payment successful and database updated!");
                        } else {
                            alert("Payment successful but database update failed!");
                        }
                    }).catch(error => {
                        console.error("Error updating database:", error);
                    });
                },
                "prefill": {
                    "name": "<?php echo isset($name) ? $name : ''; ?>",
                    "email": "user@example.com",
                    "contact": "9999999999"
                },
                "theme": {
                    "color": "#3399cc"
                }
            };
            var rzp1 = new Razorpay(options);
            rzp1.open();
        });

        function displayReceipt() {
            document.getElementById("transactionDetailsDiv").style.display = "block";
            document.getElementById("paymentAmount").innerText = sessionStorage.getItem("rupeesSum");
            document.getElementById("transactionId").innerText = sessionStorage.getItem("transactionId");
        }
    </script>
</body>

</html>